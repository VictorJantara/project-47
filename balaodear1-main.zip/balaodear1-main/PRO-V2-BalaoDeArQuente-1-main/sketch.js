var bg, bgImg
var bottomGround
var topGround
var balloon, balloonImg
var obstacleTop, obsTop1, obsTop2
var obstacleBottom, obsBottom1, obsBottom2, obsBottom3


function preload(){

}

function setup(){

//imagem de plano de fundo


//criando canto superior e inferior



      
//criando o balão     




}

function draw() {
  
  background("black");
        
          //fazendo o balão de ar quente pular
          

          //adicionando gravidade
           
   
        drawSprites();
        
}
